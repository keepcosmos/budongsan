#' extrafont package
#'
#' This package is used for using and embedding fonts other than the
#' basic Postscript fonts.
#'
#' For use instructions, see \url{https://github.com/wch/extrafont}.
#'
#' @name extrafont
#' @docType package
#' @aliases extrafont package-extrafont
#' @import extrafontdb
NULL
